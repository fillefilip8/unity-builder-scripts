Write-Output "Injecting registry keys..."

$windowsSdkDirectory = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Microsoft SDKs\Windows\v10.0"

New-Item -Path $windowsSdkDirectory -Force | Out-Null

New-ItemProperty -Path $windowsSdkDirectory `
     -Name InstallationFolder `
     -PropertyType String `
     -Force `
     -Value "C:\Program Files (x86)\Windows Kits\10\" | Out-Null

New-ItemProperty -Path $windowsSdkDirectory `
     -Name ProductVersion `
     -PropertyType String `
     -Force `
     -Value $env:WINDOWS_SDK_VERSION | Out-Null
	 
Write-Output "Injected registry keys"


if(-Not (Test-Path -Path "c:\project"))
{
    # We use -Force to suppress output, doesn't overwrite anything
    New-Item -ItemType Directory -Force -Path "c:\project"
}

Write-Output "Copying workspace to project folder..."
Copy-Item -Path "c:\workspace" -Destination "c:\project" -Recurse
Write-Output "Copied workspace to project folder"

# Activate Unity
& ".\steps\activate.ps1"

# Import any necessary registry keys, ie: location of windows 10 sdk
# No guarantee that there will be any necessary registry keys, ie: tvOS
#Get-ChildItem -Path c:\regkeys -File | Foreach {reg import $_.fullname}

# Register the Visual Studio installation so Unity can find it
regsvr32 C:\ProgramData\Microsoft\VisualStudio\Setup\x64\Microsoft.VisualStudio.Setup.Configuration.Native.dll

# Build the project
& ".\steps\build.ps1"

# Free the seat for the activated license
& ".\steps\return_license.ps1"
